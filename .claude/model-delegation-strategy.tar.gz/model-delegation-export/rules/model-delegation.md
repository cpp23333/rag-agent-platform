# Model Delegation Workflow

> Cost optimization: the main session runs on Opus (expensive, deep reasoning). Delegate routine implementation to Sonnet via the `implementer` subagent. Opus owns design + verification; Sonnet owns code writing.

## When to delegate

For any **non-trivial** coding task (≥3 files, ≥30 lines of net change, or any new feature):

1. **Opus writes the spec** — a concrete `docs/specs/<name>.md` or `docs/plans/<name>.md` describing what to build, files to change, and acceptance criteria. The spec must be specific enough that a developer who hasn't seen this conversation can implement it.
2. **Opus delegates implementation** to the `implementer` subagent via the Agent tool. Pass the spec path in the prompt, NOT the spec content inline (keeps tokens down and gives the agent a stable reference).
3. **Sonnet implements** — reads spec, writes code, runs tests, returns a summary report.
4. **Opus verifies** — independently reads the changed files, runs the test suite, checks behavior against the spec's acceptance criteria. Do NOT trust the agent's summary; verify by reading files and running commands.
5. **Opus reports to user and handles git** — commits, PRs, etc. happen from the main session.

## When NOT to delegate

Skip delegation and do it directly in the Opus session when:

- The task is a single-line fix, typo, or obvious bug.
- The task is purely investigative (reading code, answering questions, searching).
- The user has explicitly asked Opus to do the work.
- The task requires deep reasoning that Sonnet would likely get wrong (complex algorithm design, subtle concurrency, security-sensitive code).
- The scope is so small that writing a spec costs more than just implementing.

## Delegation call template

```
Agent({
  description: "Implement <feature> from spec",
  subagent_type: "implementer",
  prompt: "Read the spec at docs/specs/<name>.md and implement it.
           Context: <1-2 sentences on why this matters, anything not in the spec>.
           When done, report: files changed, tests run, deviations from spec."
})
```

The `implementer` agent's definition (`~/.claude/agents/implementer.md`) pins `model: sonnet`, so the call automatically uses Sonnet without needing a `model:` override.

## Verification checklist (Opus, after Sonnet returns)

- [ ] Read the diff: `git diff` and inspect each changed file
- [ ] Confirm each acceptance criterion from the spec is met
- [ ] Run the project's test command for the affected modules
- [ ] Check that no out-of-scope files were modified
- [ ] If anything is wrong, send a follow-up message to the same agent via the agent's ID/name (do NOT start a fresh agent — that loses context)

## Anti-patterns

- **Don't delegate without a written spec.** A 2-line task description in the Agent prompt is not a spec; it's a request, and Sonnet will fill in the gaps unpredictably.
- **Don't paste the spec inline if it already exists as a file.** Pass the path instead.
- **Don't trust the agent's "I'm done" report.** Always verify by reading the actual changes.
- **Don't let the implementer commit or push.** Those are irreversible; keep them in the Opus session where the user can intervene.
