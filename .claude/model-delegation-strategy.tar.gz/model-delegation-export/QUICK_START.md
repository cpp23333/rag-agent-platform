# 模型委托策略 - 快速开始

## 📦 安装（3 步）

```bash
# 1. 解压
tar -xzf model-delegation-strategy.tar.gz
cd model-delegation-export

# 2. 运行安装脚本
./install.sh

# 3. 验证安装
ls -l ~/.claude/rules/common/model-delegation.md
ls -l ~/.claude/agents/implementer.md
```

## 🚀 立即使用

给 Claude 一个任务，例如：

```
添加一个新的 API 端点 /api/v3/users/settings，
包括 Controller、Service、Repository 三层实现。
```

Claude 会自动：
1. ✍️ Opus 写规格文档
2. 🤖 调用 Sonnet 实现代码
3. ✅ Opus 验证质量
4. 📊 报告结果

## 💰 成本对比

| 模型 | 输入 | 输出 | 用途 |
|------|------|------|------|
| Opus 4.7 | $15/MTok | $75/MTok | 设计、验证 |
| Sonnet 4.6 | $3/MTok | $15/MTok | 编码实现 |

**节省：~80% 成本**

## 📋 核心文件

```
~/.claude/
├── rules/common/
│   └── model-delegation.md    # 委托策略规则
└── agents/
    └── implementer.md          # Sonnet 实现者
```

## ✅ 何时使用委托

- ✅ 3+ 文件修改
- ✅ 30+ 行代码
- ✅ 明确的功能需求
- ✅ 重复性编码

## ❌ 何时不用委托

- ❌ 单行修改
- ❌ 架构决策
- ❌ 探索性编程
- ❌ 复杂 bug 调试

## 🔧 故障排除

### Agent 未找到
```bash
# 检查文件是否存在
ls ~/.claude/agents/implementer.md

# 检查 frontmatter
head -5 ~/.claude/agents/implementer.md
# 应该看到：
# ---
# model: sonnet
# ---
```

### 规则未生效
```bash
# 检查规则文件
ls ~/.claude/rules/common/model-delegation.md

# 重启 Claude Code
```

## 📚 更多资源

- 完整文档：`README.md`
- 规则详情：`rules/model-delegation.md`
- Agent 定义：`agents/implementer.md`

## 🎯 测试示例

试试这个任务来测试工作流：

```
在用户表添加一个 last_login_ip 字段，
包括数据库迁移、实体类、DTO、API 响应的完整映射。
```

你会看到 Opus 和 Sonnet 的完整协作过程！
