#!/bin/bash
# 模型委托策略安装脚本

set -e

echo "=== 模型委托策略安装程序 ==="
echo ""
echo "请选择安装方式："
echo "1) 全局安装（推荐）- 所有项目可用"
echo "2) 项目级安装 - 仅当前项目可用"
echo ""
read -p "请输入选项 (1 或 2): " choice

case $choice in
  1)
    echo ""
    echo "正在进行全局安装..."
    mkdir -p ~/.claude/rules/common
    mkdir -p ~/.claude/agents
    
    cp rules/*.md ~/.claude/rules/common/
    cp agents/*.md ~/.claude/agents/
    
    echo "✅ 全局安装完成！"
    echo ""
    echo "已安装文件："
    ls -l ~/.claude/rules/common/model-delegation.md
    ls -l ~/.claude/agents/implementer.md
    ;;
    
  2)
    echo ""
    echo "正在进行项目级安装..."
    mkdir -p .claude/rules
    mkdir -p .claude/agents
    
    cp rules/*.md .claude/rules/
    cp agents/*.md .claude/agents/
    
    echo "✅ 项目级安装完成！"
    echo ""
    echo "已安装文件："
    ls -l .claude/rules/model-delegation.md
    ls -l .claude/agents/implementer.md
    ;;
    
  *)
    echo "❌ 无效选项，安装取消"
    exit 1
    ;;
esac

echo ""
echo "=== 安装完成 ==="
echo ""
echo "使用方法："
echo "1. 给 Claude 一个需要实现的功能（3+ 文件修改）"
echo "2. Opus 会自动创建规格文档"
echo "3. Opus 会调用 Sonnet (implementer agent) 实现代码"
echo "4. Opus 会验证实现质量"
echo ""
echo "成本节省：约 80%（Sonnet 比 Opus 便宜 5 倍）"
