# 模型委托策略移植包

这个包包含了 Opus 指挥 Sonnet 的模型委托工作流所需的所有配置文件。

## 文件结构

```
model-delegation-export/
├── README.md                          # 本文件
├── rules/                             # 规则文件
│   ├── model-delegation.md            # 核心：模型委托策略
│   ├── development-workflow.md        # 开发工作流
│   ├── agents.md                      # Agent 编排规则
│   └── performance.md                 # 性能优化（模型选择）
└── agents/                            # Agent 定义
    └── implementer.md                 # Sonnet 实现者 agent

## 安装步骤

### 方法 1：全局安装（推荐）

适用于所有项目使用相同的模型委托策略：

```bash
# 1. 复制规则文件到全局配置
mkdir -p ~/.claude/rules/common
cp rules/*.md ~/.claude/rules/common/

# 2. 复制 agent 定义到全局配置
mkdir -p ~/.claude/agents
cp agents/*.md ~/.claude/agents/
```

### 方法 2：项目级安装

适用于只在特定项目使用：

```bash
# 在项目根目录执行
mkdir -p .claude/rules
mkdir -p .claude/agents

cp rules/*.md .claude/rules/
cp agents/*.md .claude/agents/
```

## 工作流程

1. **Opus（主模型）** - 负责：
   - 理解需求
   - 设计方案
   - 编写规格文档（`docs/specs/*.md`）
   - 验证实现质量
   - 处理 git 操作

2. **Sonnet（实现模型）** - 负责：
   - 读取规格文档
   - 编写代码
   - 运行测试
   - 报告结果

## 使用示例

```
用户: 添加一个新的 API 端点 /api/v3/users/profile

Opus: 
1. 创建 docs/specs/add-user-profile-endpoint.md
2. 调用 implementer agent（Sonnet）实现
3. 验证代码质量和测试
4. 向用户报告结果
```

## 成本优化

- Opus 4.7: $15/MTok input, $75/MTok output（深度推理）
- Sonnet 4.6: $3/MTok input, $15/MTok output（高效编码）

通过委托实现工作给 Sonnet，可以节省约 80% 的成本。

## 何时使用委托

✅ **应该委托**：
- 涉及 3+ 个文件的修改
- 30+ 行代码变更
- 新功能实现（规格明确）
- 重复性编码工作

❌ **不应该委托**：
- 单行修改或简单 bug 修复
- 需要深度架构决策
- 探索性编程
- 用户明确要求 Opus 处理

## 验证安装

运行以下命令检查文件是否正确安装：

```bash
# 检查全局安装
ls -l ~/.claude/rules/common/model-delegation.md
ls -l ~/.claude/agents/implementer.md

# 或检查项目级安装
ls -l .claude/rules/model-delegation.md
ls -l .claude/agents/implementer.md
```

## 故障排除

### Agent 未找到
确保 `implementer.md` 在正确的位置：
- 全局：`~/.claude/agents/implementer.md`
- 项目：`.claude/agents/implementer.md`

### 规则未生效
确保规则文件在以下位置之一：
- 全局：`~/.claude/rules/common/*.md`
- 项目：`.claude/rules/*.md`

### Sonnet 未被使用
检查 `implementer.md` 的 frontmatter 是否包含：
```yaml
---
model: sonnet
---
```

## 更多信息

- Claude Code 文档: https://docs.anthropic.com/claude/docs
- Agent 系统: https://docs.anthropic.com/claude/docs/agents
